# Proposal -  Jeep Run

### Group Members
- Dean Sabbah
- Marko Celenkovic

### Setting
- Takes place in zombie infested desert
- Goal is to escape zombies and make it to a hideout/safespace

### Design
- Control a jeep w/ a turret
- Has either machine/gattling gun or missile launcher
- Enemy types:
    - Wandering zonbie (slow, melee)
    - Zombie w/ gun (Keeps distance, shoots at player)
    - Kamikaze zombie (Runs towards enemy, explodes on collision + death (?))
    - Glider zombie (Can't be run over, quick, ranged weapon) - (If we have time) (Could be other type of special enemy)
- Collectables:
    - Health collectable (Regenerates health)
    - Incincibility
    - Improved ammo (Makes gattling gun shots explode/do more damage)
    - Speed bost
    - Jeep gun (shoots from the front of the Jeep) - (If we have time)
    - Ray gun upgrade (Special weapon, one time shot, deals lots of damage, constant for multiple seconds) - (If we have time)
- Zombies will have advanced steering behaviours
- HUD:
    - Ammo count (either player has to relaod xor collect ammo on ground)
    - Health bar/count
    - Time left to find safezone
    - Minimap (if we have time)
- Jeep turret follows the mouse to aim
- Control the jeep w/ wasd keys

### Extra (If we have time 😢)
- Extra maze level in city
- Music + sound effects (would be nice)
- Advanced tactical AI for glider zombie

### Timeline
- Start looking for assets asap
- March 2, use assignment as base for assignment. Should have Enemies + enemy movement, Jeep movement, some ofcollectables done.
- Use ported assingment as base for Assignment 4. Should mean that Jeep turret is implementd by March 23.
- Start work on HUD, 4 days.
- Implement rest of collectables, 3 days.
- Implement win condition, 2 days.
- Work on extra features